#import <Flutter/Flutter.h>

@interface KosherDartPlugin : NSObject<FlutterPlugin>
@end
